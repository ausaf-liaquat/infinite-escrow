@php echo $body @endphp
